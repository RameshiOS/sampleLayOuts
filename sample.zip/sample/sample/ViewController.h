//
//  ViewController.h
//  sample
//
//  Created by InfoBrain on 05/01/17.
//  Copyright © 2017 InfoBrain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

