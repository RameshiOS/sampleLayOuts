//
//  ViewController.m
//  sample
//
//  Created by InfoBrain on 05/01/17.
//  Copyright © 2017 InfoBrain. All rights reserved.
//

#import "ViewController.h"
#import "MBProgressHUD.h"
@interface ViewController ()
{
    UIButton *showButton;
    UITextView *textView_p;
}
@property (weak, nonatomic) IBOutlet UISwitch *switch_P;
@property (weak, nonatomic) IBOutlet UISlider *sliderView;
@property (weak, nonatomic) IBOutlet UIView *colorView;
@end

@implementation ViewController




- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    showButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [showButton addTarget:self
               action:@selector(ClickButton)
     forControlEvents:UIControlEventTouchUpInside];
    [showButton setTitle:@"Show View" forState:UIControlStateNormal];
    [showButton setBackgroundColor:[UIColor grayColor]];
    showButton.frame = CGRectMake(80.0, 80.0, 160.0, 40.0);
    [self.view addSubview:showButton];
    
   
    self.switch_P.center = CGPointMake(150, 200);
    [self.switch_P addTarget:self action:@selector(switched:)
       forControlEvents:UIControlEventValueChanged];
    [self.switch_P setOn:NO animated:YES];
    
    
}
- (IBAction)sliderChanged:(id)sender {
   
    self.sliderView.maximumValue = 1000.0f;
    self.sliderView.value = [textView_p.text floatValue];

    
    [self switched:nil];
}

-(IBAction)switched:(id)sender{
    NSLog(@"Switch current state %@", self.switch_P.on ? @"On" : @"Off");
    
    textView_p.hidden  = YES;
    [textView_p removeFromSuperview];
 
    if ([self.switch_P isOn]) {
        NSLog(@"its on!");
        [self.switch_P setOn:NO animated:YES];
      
    } else {
        NSLog(@"its off!");
        [self.switch_P setOn:YES animated:YES];
       

    }
    
}
-(void)ClickButton{
    //Hyderabad
  [MBProgressHUD showGlobalProgressHUDWithTitle:@"Laoding..."];
   // [progressView show:true];
    NSString *urlStr = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/distancematrix/json?origins=Hyderabad&destinations=Vijaywada&sensor=false"];
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
    NSURL *url = [NSURL URLWithString:urlStr];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];

 
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *resp, NSError *error) {
      
     //   [progressView removeFromSuperview];
        NSDictionary *rspDic = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        NSLog(@"+++++%@",rspDic);
        
        
        if ((resp == (id)[NSNull null]) ||(resp==nil)) {
        }else{
            NSString *   strStatusCode  = [NSString stringWithFormat:@"%@",[rspDic objectForKey:@"statusCode"]];
            //NSLog(@"strStatus:%@",self.strStatus);
            
            
            dispatch_async(dispatch_get_main_queue(), ^(void){
                //Run UI Updates
                [MBProgressHUD dismissGlobalHUD];
                CGRect frame = showButton.bounds;
                frame.size.height += 50.0f;
                frame.size.width += 20.0f;
                frame.origin.y += 140;
                frame.origin.x = 80;

             NSString *string  = [[[[[[[rspDic objectForKey:@"rows"] objectAtIndex:0] objectForKey:@"elements"] objectAtIndex:0] objectForKey:@"distance"] objectForKey:@"text"] stringByReplacingOccurrencesOfString:@" km" withString:@""];
                
                textView_p = [[UITextView alloc]initWithFrame:frame];
                [textView_p setText:[NSString stringWithFormat:@"%@",string]];
                [self.view addSubview:textView_p];
                textView_p.backgroundColor = [UIColor grayColor];
                
                [self sliderChanged:nil];
            });
            
            if ([strStatusCode integerValue]==200) {
                
                NSLog(@"%@",resp);
             
                //  [self showAlert:@"Sucess" message:strStatus];
            }else{
                //  Toast *mtost = [Toast toastWithMessage:[rspDic objectForKey:@"errorMessage"]];
                //  [mtost showOnView:self.view];
            }
            
            
        }
        
    }];
    
    [postDataTask resume];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
